/**
 * @file main.c
 * @brief PIC32 Ground StationStation
 *
 * Modified from Sir de Villa's code
 * 
 * @author Alberto de Villa <alberto.de.villa@eee.upd.edu.ph>
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 */

// Common include for the XC32 compiler
#include <xc.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "platform.h"

//////////////////////////////////////////////////////////////////////////////

// Program state machine
typedef struct prog_state_type{
  // Flags for this program
#define PROG_FLAG_UPDATE_PENDING        0x0001  // Waiting to transmit updates   
#define PROG_FLAG_GEN_COMPLETE          0x8000  // Message generation has been done, but transmission has not occurred
    
  uint16_t flags;
  
    // Transmit stuff
    platform_usart_tx_bufdesc_t tx_desc[4];
    char tx_buf[256];
    uint16_t tx_blen;
    
    // Receive from CanSat to Ground
    platform_usart_rx_async_desc_t comms_rx_desc;
    uint16_t comms_rx_desc_blen;
    char comms_rx_desc_buf[256];
    
} prog_state_t;

/*
 * Initialize the main program state
 * 
 * This style might be familiar to those accustomed to he programming
 * conventions employed by the Arduino platform.
 */
static void prog_setup(prog_state_t *ps){
  memset(ps, 0, sizeof(*ps));
  
    platform_init();
      
    // SERCOM0 - HC-12
    ps->comms_rx_desc.buf     = ps->comms_rx_desc_buf;
    ps->comms_rx_desc.max_len = sizeof(ps->comms_rx_desc_buf);
    
    platform_usart_comms_rx_async(&ps->comms_rx_desc);
    return;
}


/*
 * Do a single loop of the main program
 * 
 * This style might be familiar to those accustomed to he programming
 * conventions employed by the Arduino platform.
 */
static void prog_loop_one(prog_state_t *ps){    
    uint16_t a = 0;

    // Do one iteration of the platform event loop first.
    platform_do_loop_one();

    ////////////////////////////////////////////////////////////////////
    
    // Something from the SERCOM1 UART?
    char buffer[256];
    if (!platform_usart_comms_rx_busy() && ps->comms_rx_desc.compl_type == PLATFORM_USART_RX_COMPL_DATA) {
        sprintf(buffer, ps->comms_rx_desc_buf);
        PORT_SEC_REGS->GROUP[0].PORT_OUTSET = (1 << 15);
        ps->flags |= PROG_FLAG_UPDATE_PENDING;
        memset(ps->comms_rx_desc_buf, 0, sizeof(ps->comms_rx_desc_buf));
        platform_usart_comms_rx_async(&ps->comms_rx_desc);
    }

    // Process any pending Comms update flags
    do {
    if ((ps->flags & PROG_FLAG_UPDATE_PENDING) == 0)
      break;
    
    if (platform_usart_cdc_tx_busy())
      break;
    
    if ((ps->flags & PROG_FLAG_GEN_COMPLETE) == 0) {
        ps->tx_desc[0].buf = buffer;
        ps->tx_desc[0].len = strlen(buffer);
    }
    
    if (platform_usart_cdc_tx_async(&ps->tx_desc[0], 1)) {
        PORT_SEC_REGS->GROUP[0].PORT_OUTCLR = (1 << 15);
        
        memset(ps->comms_rx_desc_buf, 0, sizeof(ps->comms_rx_desc_buf));
        platform_usart_comms_rx_async(&ps->comms_rx_desc);
        
        ps->flags &= ~(PROG_FLAG_UPDATE_PENDING | PROG_FLAG_GEN_COMPLETE);
    }
  } while (0);
  
  // Done
  return;
}

// main() -- the heart of the program
int main(void){
  prog_state_t ps;
  
  // Initialization time  
  prog_setup(&ps);
  
  /*
   * Microcontroller main()'s are supposed to never return (welp, they
   * have none to return to); hence the intentional infinite loop.
   */
  for (;;) {
    prog_loop_one(&ps);
  }
    
    // This line must never be reached
    return 1;
}
