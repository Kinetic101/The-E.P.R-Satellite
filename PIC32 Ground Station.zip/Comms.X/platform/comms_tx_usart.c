/**
 * @file platform/usart.c
 * @brief Platform-support routines, USART component
 *
 * @author Alberto de Villa <alberto.de.villa@eee.upd.edu.ph>
 * @date   28 Oct 2024
 */

/*
 * PIC32CM5164LS00048 initial configuration:
 * -- Architecture: ARMv8 Cortex-M23
 * -- GCLK_GEN0: OSC16M @ 4 MHz, no additional prescaler
 * -- Main Clock: No additional prescaling (always uses GCLK_GEN0 as input)
 * -- Mode: Secure, NONSEC disabled
 * 
 * HW configuration for the corresponding Curiosity Nano+ Touch Evaluation
 * Board:
 * -- PB17: UART via debugger (RX, SERCOM1, PAD[1])
 */

// Common include for the XC32 compiler
#include <xc.h>
#include <stdbool.h>
#include <string.h>

#include "../platform.h"

// Functions "exported" by this file
void comms_tx_platform_usart_init(void);
void comms_tx_platform_usart_tick_handler(const platform_timespec_t *tick);

/////////////////////////////////////////////////////////////////////////////

/**
 * State variables for UART
 * 
 * NOTE: Since these are shared between application code and interrupt handlers
 *       (SysTick and SERCOM), these must be declared volatile.
 */
typedef struct ctx_usart_type {
	
	/// Pointer to the underlying register set
	sercom_usart_int_registers_t *regs;
	
	/// State variables for the transmitter
	struct {
		volatile platform_usart_tx_bufdesc_t *desc;
		volatile uint16_t nr_desc;
		
		// Current descriptor
		volatile const char *buf;
		volatile uint16_t    len;
	} tx;
	
	/// Configuration items
	struct {
		/// Idle timeout (reception only)
		platform_timespec_t ts_idle_timeout;
	} cfg;
	
} comms_tx_ctx_usart_t;
static comms_tx_ctx_usart_t comms_tx_ctx_uart;

// Configure USART
void comms_tx_platform_usart_init(void){
	/*
	 * For ease of typing, #define a macro corresponding to the SERCOM
	 * peripheral and its internally-clocked USART view.
	 * 
	 * To avoid namespace pollution, this macro is #undef'd at the end of
	 * this function.
	 */
#define UART_REGS (&(SERCOM0_REGS->USART_INT))
	
	/*
	 * Enable the APB clock for this peripheral
	 * 
	 * NOTE: The chip resets with it enabled; hence, commented-out.
	 * 
	 * WARNING: Incorrect MCLK settings can cause system lockup that can
	 *          only be rectified via a hardware reset/power-cycle.
	 */
	// MCLK_REGS->MCLK_APB???MASK |= (1 << ???);
	
	/*
	 * Enable the GCLK generator for this peripheral
	 * 
	 * NOTE: GEN2 (4 MHz) is used, as GEN0 (24 MHz) is too fast for our
	 *       use case.
	 */
	GCLK_REGS->GCLK_PCHCTRL[17] = 0x00000042;
	while ((GCLK_REGS->GCLK_PCHCTRL[17] & 0x00000040) == 0) asm("nop");
	
	// Initialize the peripheral's context structure
	memset(&comms_tx_ctx_uart, 0, sizeof(comms_tx_ctx_uart));
	comms_tx_ctx_uart.regs = UART_REGS;
	
	/*
	 * This is the classic "SWRST" (software-triggered reset).
	 * 
	 * NOTE: Like the TC peripheral, SERCOM has differing views depending
	 *       on operating mode (USART_INT for UART mode). CTRLA is shared
	 *       across all modes, so set it first after reset.
	 */
	UART_REGS->SERCOM_CTRLA = (0x1 << 0);
	while((UART_REGS->SERCOM_SYNCBUSY & (0x1 << 0)) != 0) asm("nop");
	UART_REGS->SERCOM_CTRLA = (uint32_t)(0x1 << 2);
		
	/*
	 * Select further settings compatible with the 16550 UART:
	 * 
	 * - 16-bit oversampling, arithmetic mode (for noise immunity) A
	 * - LSB first A 
	 * - No parity A
	 * - Two stop bits B
	 * - 8-bit character size B
	 * - No break detection 
	 * 
	 * - Use PAD[0] for data transmission A
	 * - Use PAD[1] for data reception A
	 * 
	 * NOTE: If a control register is not used, comment it out.
	 */
	UART_REGS->SERCOM_CTRLA |= (0x0 << 13) | (0x1 << 30) | (0x0 << 24) | (0x2 << 16);
	UART_REGS->SERCOM_CTRLB |= (0x0 << 6) | (0x0 << 0);
	//UART_REGS->SERCOM_CTRLC |= ???;
	
	/*
	 * This value is determined from f_{GCLK} and f_{baud}, the latter
	 * being the actual target baudrate (here, 9600 bps).
	 */
	UART_REGS->SERCOM_BAUD = 0xF62B;
	
	/*
	 * Configure the IDLE timeout, which should be the length of 3
	 * USART characters.
	 * 
	 * NOTE: Each character is composed of 8 bits (must include parity
	 *       and stop bits); add one bit for margin purposes. In addition,
	 *       for UART one baud period corresponds to one bit.
	 */
	comms_tx_ctx_uart.cfg.ts_idle_timeout.nr_sec  = 0;
	comms_tx_ctx_uart.cfg.ts_idle_timeout.nr_nsec = 781250;
	
	/*
	 * Third-to-the-last setup:
	 * 
	 * - Enable receiver and transmitter
	 * - Clear the FIFOs (even though they're disabled)
	 */
    
	UART_REGS->SERCOM_CTRLB |= (0x1 << 16) | (0x3 << 22);
	while ((UART_REGS->SERCOM_SYNCBUSY & (0x1 << 2)) != 0) asm("nop");
    
	/*
	 * Second-to-last: Configure the physical pins.
	 * 
	 * NOTE: Consult both the chip and board datasheets to determine the
	 *       correct port pins to use.
	 */
    PORT_SEC_REGS->GROUP[0].PORT_DIRCLR = (1 << 16);
    
	PORT_SEC_REGS->GROUP[0].PORT_PINCFG[16] = 0x3;
    
	PORT_SEC_REGS->GROUP[0].PORT_PMUX[8] = 0x3;
    
    
    // Last: enable the peripheral, after resetting the state machine
	UART_REGS->SERCOM_CTRLA |= (0x1 << 1);
	while ((UART_REGS->SERCOM_SYNCBUSY & (0x1 << 1)) != 0) asm("nop");
	return;

#undef UART_REGS
}

// Tick handler for the USART
static void comms_tx_usart_tick_handler_common(
	comms_tx_ctx_usart_t *ctx, const platform_timespec_t *tick)
{	
	// TX handling
	if ((ctx->regs->SERCOM_INTFLAG & (1 << 0)) != 0) {
		if (ctx->tx.len > 0) {
			/*
			 * There is still something to transmit in the working
			 * copy of the current descriptor.
			 */
			ctx->regs->SERCOM_DATA = *(ctx->tx.buf++);
			--ctx->tx.len;
		}
		if (ctx->tx.len == 0) {
			// Load a new descriptor
			ctx->tx.buf = NULL;
			if (ctx->tx.nr_desc > 0) {
				/*
				 * There's at least one descriptor left to
				 * transmit
				 * 
				 * If either ->buf or ->len of the candidate
				 * descriptor refer to an empty buffer, the
				 * next invocation of this routine will cause
				 * the next descriptor to be evaluated.
				 */
				ctx->tx.buf = ctx->tx.desc->buf;
				ctx->tx.len = ctx->tx.desc->len;
				
				++ctx->tx.desc;
				--ctx->tx.nr_desc;
					
				if (ctx->tx.buf == NULL || ctx->tx.len == 0) {
					ctx->tx.buf = NULL;
					ctx->tx.len = 0;
				}
			} else {
				/*
				 * No more descriptors available
				 * 
				 * Clean up the corresponding context data so
				 * that we don't trip over them on the next
				 * invocation.
				 */
				ctx->regs->SERCOM_INTENCLR = 0x01;
				ctx->tx.desc = NULL;
				ctx->tx.buf = NULL;
			}
		}
	}
	// Done
	return;
}

void comms_tx_platform_usart_tick_handler(const platform_timespec_t *tick)
{
	comms_tx_usart_tick_handler_common(&comms_tx_ctx_uart, tick);
}

/// Maximum number of bytes that may be sent (or received) in one transaction
#define NR_USART_CHARS_MAX (65528)

/// Maximum number of fragments for USART TX
#define NR_USART_TX_FRAG_MAX (32)

// Enqueue a buffer for transmission
static bool comms_tx_usart_tx_busy(comms_tx_ctx_usart_t *ctx)
{
	return (ctx->tx.len > 0) || (ctx->tx.nr_desc > 0) ||
		((ctx->regs->SERCOM_INTFLAG & (1 << 0)) == 0);
}

static bool comms_tx_usart_tx_async(comms_tx_ctx_usart_t *ctx,
	const platform_usart_tx_bufdesc_t *desc,
	unsigned int nr_desc)
{
	uint16_t avail = NR_USART_CHARS_MAX;
	unsigned int x, y;
	
	if (!desc || nr_desc == 0)
		return true;
	else if (nr_desc > NR_USART_TX_FRAG_MAX)
		// Too many descriptors
		return false;
	
	// Don't clobber an existing buffer
	if (comms_tx_usart_tx_busy(ctx))
		return false;
	
	for (x = 0, y = 0; x < nr_desc; ++x) {
		if (desc[x].len > avail) {
			// IF the message is too long, don't enqueue.
			return false;
		}
		
		avail -= desc[x].len;
		++y;
	}
	
	// The tick will trigger the transfer
	ctx->tx.desc = desc;
	ctx->tx.nr_desc = nr_desc;
	return true;
}

static void comms_tx_usart_tx_abort(comms_tx_ctx_usart_t *ctx)
{
	ctx->tx.nr_desc = 0;
	ctx->tx.desc = NULL;
	ctx->tx.len = 0;
	ctx->tx.buf = NULL;
	return;
}

// API-visible items
bool comms_tx_platform_usart_cdc_tx_async(
	const platform_usart_tx_bufdesc_t *desc,
	unsigned int nr_desc)
{
	return comms_tx_usart_tx_async(&comms_tx_ctx_uart, desc, nr_desc);
}

bool comms_tx_platform_usart_cdc_tx_busy(void)
{
	return comms_tx_usart_tx_busy(&comms_tx_ctx_uart);
}

void comms_tx_platform_usart_cdc_tx_abort(void)
{
	comms_tx_usart_tx_abort(&comms_tx_ctx_uart);
	return;
}