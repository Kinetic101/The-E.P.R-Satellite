/**
 * @file aht10.h
 * @brief Header file for aht10.c
 *
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 * @date   13 May 2025
 */

#ifndef AHT10_H
#define	AHT10_H

#ifdef	__cplusplus
extern "C" {
#endif

void AHT10_Initialize();

void read_temp_humidity(double* humi, double* temp);


#ifdef	__cplusplus
}
#endif

#endif	/* AHT10_H */

