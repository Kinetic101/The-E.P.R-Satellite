/**
 * @file adc.h
 * @brief Helper file for adc.c
 *
 * @author Kent Palima <kent.joseph.palima@eee.upd.edu.ph>
 */

#ifndef ADC_H
#define ADC_H

#ifdef __cplusplus
extern "C" {
#endif

/* Initialize ADC module */
void ADC_Initialize(void);

/* Enable ADC module */
void ADC_Enable(void);

/* Start the ADC conversion by SW */
void ADC_ConversionStart(void);

/* Read the conversion result */
uint16_t ADC_ConversionResultGet(void);

/* Check whether result is ready */
bool ADC_ConversionStatusGet(void);

/* Get result */
void read_co2(uint32_t*);

#ifdef __cplusplus
}
#endif

#endif // MY_HEADER_H
