/**
 * @file pms_parser.h
 * @brief Header file for pms_parser.c
 *
 * @author Christian Klein Ramos <christian.klein.ramos@eee.upd.edu.ph>
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 */

#ifndef PMS_PARSER_H
#define	PMS_PARSER_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdbool.h>
#include <stdint.h>
    
#include "main.h"
    
bool verify_pm(uint8_t* buffer);
bool read_pm(prog_state_t *ps);

#ifdef	__cplusplus
}
#endif

#endif	/* PMS_PARSER_H */

