/** 
 * @file   main.h
 * @brief Declare struct for program state
 *
 * Modified from Sir de Villa's code from EEE 158
 * 
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 * @author Christian Klein Ramos <christian.klein.ramos@eee.upd.edu.ph>
 * @author Kent Joseph Palima <kent.joseph.palima@eee.upd.edu.ph>
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "platform.h"
    
// Program state machine
typedef struct prog_state_type{
	// Flags for this program
	#define PROG_FLAG_GPS_UPDATE_PENDING    0x0001	// Waiting to transmit GPS
    #define PROG_FLAG_PM_UPDATE_PENDING     0x0002	// Waiting to transmit PM
    #define PROG_FLAG_I2C_UPDATE_PENDING    0x0004	// Waiting to transmit I2Cs
    #define PROG_FLAG_CO2_UPDATE_PENDING    0x0008	// Waiting to transmit CO2
	#define PROG_FLAG_GEN_COMPLETE          0x8000	// Message generation has been done, but transmission has not occurred
    
	uint16_t flags;

	// CDC transmit stuff
	platform_usart_tx_bufdesc_t tx_desc[4];
	char tx_buf[256];
	uint16_t tx_blen;    
    
    // PMS7003
    platform_usart_rx_async_desc_t pm_rx_desc;
    char pm_rx_desc_buf[32];
    uint16_t pm1_0;
    uint16_t pm2_5;
    uint16_t pm10;
    
    // NEO6M
    platform_usart_rx_async_desc_t gps_rx_desc;
    char gps_rx_desc_buf[128];
    char gpgll[64*2 + 12 + 10];
    
    // AHT10
    double tem, hum;
    
    // BMP180
    double alt;
    uint32_t pre;
    
    // MQ135
    uint32_t co2;
    
    // Timing Control for I2C
    platform_timespec_t i2c_time;
    
} prog_state_t;


#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

