/**
 * @file tc.h
 * @brief Header file for tc.c
 *
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 */

#ifndef TC_H
#define	TC_H

#ifdef	__cplusplus
extern "C" {
#endif
    
void TC_init();

void reset_tc();

void change_timer(int sense);

int read_tc();
    
#ifdef	__cplusplus
}
#endif

#endif	/* TC_H */

