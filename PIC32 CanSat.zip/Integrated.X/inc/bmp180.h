/**
 * @file bmp180.h
 * @brief Header file for bmp180.c
 *
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 * @date   13 May 2025
 */

#ifndef BMP180_H
#define	BMP180_H

#ifdef	__cplusplus
extern "C" {
#endif

void read_altitude(double* alt, uint32_t* pre);

#ifdef	__cplusplus
}
#endif

#endif	/* BMP180_H */

