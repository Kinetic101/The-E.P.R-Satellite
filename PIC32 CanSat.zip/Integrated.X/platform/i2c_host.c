/**
 * @file i2c_host.c
 * @brief I2C functions for I2C devices
 *
 * Modified to add write and read functions for I2C
 * 
 * @author Allen Jason Tan <allen.jason.tan@eee.upd.edu.ph>
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 */

#include <xc.h>

#include "../inc/platform.h"

/*
    Initialization function based off code generated through Microchip Code Configurator. (c) Microchip Inc.
    Read/Write functions written by Allen.
*/

void SERCOM2_I2C_Clock_Init() {
    // All APB C bus peripheral clocks are enabled by default, so this isn't necessary
	// MCLK_REGS->MCLK_APBCMASK |= (1 << 3);
	
	// Set clock to GEN2 (4MHz)
	GCLK_REGS->GCLK_PCHCTRL[19] = 0x00000042;
	while ((GCLK_REGS->GCLK_PCHCTRL[19] & 0x00000040) == 0) asm("nop");
}

void SERCOM2_I2C_Abort();

void SERCOM2_I2C_Initialize(void){
    SERCOM2_I2C_Clock_Init();
    
    /* Reset the module */
    SERCOM2_REGS->I2CM.SERCOM_CTRLA = SERCOM_I2CM_CTRLA_SWRST_Msk ;

    /* Wait for synchronization */
    while((SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY) != 0U){
        /* Do nothing */
    }

    /* Enable smart mode, set smart mode response to ACK */
    SERCOM2_REGS->I2CM.SERCOM_CTRLB = SERCOM_I2CM_CTRLB_SMEN_Msk;

    /* Wait for synchronization */
    while((SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY) != 0U){
        /* Do nothing */
    }

    /* Baud rate - Master Baud Rate*/
    SERCOM2_REGS->I2CM.SERCOM_BAUD = 0xE8;
    
    // enable interrupts for ERROR, SB, MB (but not their NVIC interrupt lines)
    SERCOM2_REGS->I2CM.SERCOM_INTENSET |= SERCOM_I2CM_INTENSET_MB(1) | SERCOM_I2CM_INTENSET_SB(1) | SERCOM_I2CM_INTENSET_ERROR(1);
    
    // configure pins here
    // PA12 (SDA) and PA13 (SCL)
    PORT_SEC_REGS->GROUP[0].PORT_PMUX[6] = 0x22;
	PORT_SEC_REGS->GROUP[0].PORT_PINCFG[13] = 0x03;
	PORT_SEC_REGS->GROUP[0].PORT_PINCFG[12] = 0x03;

    /* Set Operation Mode (Master), SDA Hold time, run in stand by and i2c master enable */
    SERCOM2_REGS->I2CM.SERCOM_CTRLA = SERCOM_I2CM_CTRLA_INACTOUT(0x2) | SERCOM_I2CM_CTRLA_MODE_I2C_MASTER | SERCOM_I2CM_CTRLA_SDAHOLD_75NS | SERCOM_I2CM_CTRLA_SPEED_SM | SERCOM_I2CM_CTRLA_SCLSM(0UL) | SERCOM_I2CM_CTRLA_ENABLE_Msk;

    /* Wait for synchronization */
    while((SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY) != 0U){
        /* Do nothing */
    }

    /* Initial Bus State: IDLE */
    SERCOM2_REGS->I2CM.SERCOM_STATUS = (uint16_t)SERCOM_I2CM_STATUS_BUSSTATE(0x01UL);

    /* Wait for synchronization */
    while((SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY) != 0U){
        /* Do nothing */
    }
}

uint16_t SERCOM2_I2C_Write_Polled(uint8_t addr, int16_t *buf, uint16_t len, uint8_t cond) {
    uint8_t flags = 0;
    uint16_t pos = 0;
    uint32_t temp = 0;
    
    // Step 0: Wait for the bus to become idle
    // Either wait for the bus to become idle or break if not idle
    while(SERCOM2_REGS->I2CM.SERCOM_STATUS != (0x1) << 4);
    
    // Step 1: Initialize transfer by writing to ADDR (ADDR[0] indicates direction)
    SERCOM2_REGS->I2CM.SERCOM_ADDR = ((addr << 1) | (0x0 << 0));
    
    // Wait
    while (SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY & 0x4);
    
    // Step 2: Wait for and process interrupt flags
    // if error, abort and exit
    if ((SERCOM2_REGS->I2CM.SERCOM_STATUS  & (1 << 1)) ||
        (SERCOM2_REGS->I2CM.SERCOM_STATUS  & (1 << 2)) ||      // if STATUS.RXNACK
        (SERCOM2_REGS->I2CM.SERCOM_INTFLAG & (1 << 1)) ||      // if INTFLAG.SB
        (SERCOM2_REGS->I2CM.SERCOM_INTFLAG & (1 << 7))){       // if INTFLAG.ERR
        SERCOM2_I2C_Abort();
        return pos;
    }
    
    // Step 3: Write data, wait for ACKs
    for (pos; pos < len; pos++) {
        // Wait
        while ((SERCOM2_REGS->I2CM.SERCOM_INTFLAG & 0x1) != 0x1);
        
        // write data
        SERCOM2_REGS->I2CM.SERCOM_DATA = buf[pos];
        
        // Wait
        while (SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY & (1 << 2));
        
        // check for ack
        // if error, abort and exit
        if ((SERCOM2_REGS->I2CM.SERCOM_STATUS & (1 << 2)) ||  // STATUS.RXNACK 
            (SERCOM2_REGS->I2CM.SERCOM_STATUS & (1 << 1))){   // STATUS.ARBLOST
            SERCOM2_I2C_Abort();
            return 0;
        }      
        
    }
    
    while ((SERCOM2_REGS->I2CM.SERCOM_INTFLAG & 0x1) != 0x1) asm("nop");
    
    // Step 4: Issue stop condition and return state back to idle
    if(cond == 0){ // No repeated start
        SERCOM2_REGS->I2CM.SERCOM_CTRLB |= (0x3 << 16);
    }
    else{ // Repeated start
        SERCOM2_REGS->I2CM.SERCOM_CTRLB |= (0x1 << 16);
    }
    
    while (SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY & (0x1 << 2)) asm("nop");
    
    if(cond == 0){ // No repeated start so let it return to IDLE
        while(SERCOM2_REGS->I2CM.SERCOM_STATUS != (0x1) << 4) asm("nop");
    }
    
    return pos;
}

uint16_t SERCOM2_I2C_Read_Polled(uint8_t addr, int16_t* buf, uint16_t len, uint8_t cond) {
    uint8_t flags = 0;
    uint16_t pos = 0;
    uint32_t temp = 0;
        
    // Step 0: Wait for the bus to become idle
    // Either wait for the bus to become idle or break if not idle   
    if(cond == 0){ // No repeated start
        while(SERCOM2_REGS->I2CM.SERCOM_STATUS != (0x1) << 4) asm("nop");
    }
    
    // Step 1: Initialize transfer by writing to ADDR (ADDR[0] indicates direction)
    SERCOM2_REGS->I2CM.SERCOM_ADDR = ((addr << 1) | (0x1 << 0)); 
    while (SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY & 0x4) asm("nop");
    
    // Step 2: Wait for and process interrupt flags
    // if error, abort and exit
    if ((SERCOM2_REGS->I2CM.SERCOM_STATUS  & (1 << 1)) ||
        (SERCOM2_REGS->I2CM.SERCOM_STATUS  & (1 << 2)) ||  // STATUS.RXNACK
        (SERCOM2_REGS->I2CM.SERCOM_INTFLAG & (1 << 1)) ||  // INTFLAG.SB
        (SERCOM2_REGS->I2CM.SERCOM_INTFLAG & (1 << 7))) {  // INTFLAG.ERR
        SERCOM2_I2C_Abort();
        return 0;
    }
       
    // Step 3: Read data, respond with ACKs (I2C smart mode automatically sends an ACK when DATA is read)
    for (pos = 0; pos < len - 1; pos++) {
        // wait for data
        // first iteration of the loop will skip waiting because data's already there
        while ((SERCOM2_REGS->I2CM.SERCOM_INTFLAG & SERCOM_I2CM_INTFLAG_SB_Msk) != SERCOM_I2CM_INTFLAG_SB(0x1));
        
        // read data
        buf[pos] = (int16_t) SERCOM2_REGS->I2CM.SERCOM_DATA;
        
        // if error, abort and exit
        if ((SERCOM2_REGS->I2CM.SERCOM_STATUS & (1 << 2)) || 
            (SERCOM2_REGS->I2CM.SERCOM_STATUS & (1 << 1)) )  {  // STATUS.ARBLOST 
            SERCOM2_I2C_Abort();
            return 0;
        }
        
    }
    
    // Step 4: Issue stop condition and return state back to idle
    while ((SERCOM2_REGS->I2CM.SERCOM_INTFLAG & SERCOM_I2CM_INTFLAG_SB_Msk) != SERCOM_I2CM_INTFLAG_SB(0x1)) asm("nop");
    
    /* 
     * SET CTRLB.ACKACT = 0x1 to set ACKACT = NACK 
     * SET CTRLB.CMD    = 0x3 to send ACKACT (NACK), then trigger stop condition
     */
    SERCOM2_REGS->I2CM.SERCOM_CTRLB |= SERCOM_I2CM_CTRLB_ACKACT_Msk | SERCOM_I2CM_CTRLB_CMD(3UL);
    // SYNCBUSY.SYSOP is busy when you write to SERCOM_CTRLB
    while (SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY != 0U) asm("nop");
    
    // Read DATA.DATA to send a NACK and STOP condition. 
    buf[pos] = (int16_t) SERCOM2_REGS->I2CM.SERCOM_DATA;
    
    // Wait until IDLE
    while((SERCOM2_REGS->I2CM.SERCOM_STATUS & SERCOM_I2CM_STATUS_BUSSTATE_Msk) != SERCOM_I2CM_STATUS_BUSSTATE(0x01U)) asm("nop");   
    
    return pos;
}

void SERCOM2_I2C_Abort() {
    // turn it off and on again
    SERCOM2_REGS->I2CM.SERCOM_CTRLA &= ~SERCOM_I2CM_CTRLA_ENABLE_Msk;
    while((SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY) != 0);

    SERCOM2_REGS->I2CM.SERCOM_CTRLA |= SERCOM_I2CM_CTRLA_ENABLE_Msk;
    while((SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY) != 0);

    // reinitialize state to idle
    SERCOM2_REGS->I2CM.SERCOM_STATUS = (uint16_t)SERCOM_I2CM_STATUS_BUSSTATE(0x01UL);
    while((SERCOM2_REGS->I2CM.SERCOM_SYNCBUSY) != 0);    
}