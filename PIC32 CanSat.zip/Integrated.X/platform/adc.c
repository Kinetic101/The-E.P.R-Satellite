/**
 * @file adc.c
 * @brief ADC for MQ135
 *
 * Functions for ADC 
 *
 * @author Kent Palima <kent.joseph.palima@eee.upd.edu.ph>
 */

#include <xc.h>
#include <stdbool.h>
#include <math.h>
#include "../inc/adc.h"

/* Initialize ADC module */
void ADC_Initialize (void)
{
    // ADC Bus Clock : Generic Clock Generator Value | Channel Enable
    GCLK_REGS -> GCLK_PCHCTRL [28] = (0<<0) | (1 <<6);
    while (( GCLK_REGS -> GCLK_PCHCTRL [28] & (1 <<6) ) != (1 <<6));
    
    // Reset ADC *
    ADC_REGS -> ADC_CTRLA = (1<<0) ;
    while (( ADC_REGS -> ADC_SYNCBUSY & (1 <<0) )==(1<<0));
    
    /* Prescaler */
    ADC_REGS -> ADC_CTRLB = (2<<0) ;
    
    /* Sampling length */
    ADC_REGS -> ADC_SAMPCTRL = (3<<0) ;
    
    /* Reference */
    ADC_REGS -> ADC_REFCTRL = (3<<0) ;
    
    /* Input pin */
    ADC_REGS -> ADC_INPUTCTRL = (0x00<<0) ;
    
    /* Resolution & Operation Mode */
    ADC_REGS -> ADC_CTRLC = (uint16_t) ((0<<4) | (0<<8) ) ;
    
    /* Clear all interrupt flags */
    ADC_REGS -> ADC_INTFLAG = ( uint8_t ) 0x07;
    
//    uint32_t timeout = 10000;
    while (0U != ADC_REGS -> ADC_SYNCBUSY );
    //if (timeout-- <= 0) return 300;
}

/* Enable ADC module */
void ADC_Enable ( void ){
    ADC_REGS->ADC_CTRLA |= (1<<1);
    while (0U != ADC_REGS-> ADC_SYNCBUSY );
}

/* Start the ADC conversion by SW */
void ADC_ConversionStart ( void ){
    ADC_REGS-> ADC_SWTRIG |= (1<<1);
    while (( ADC_REGS->ADC_SYNCBUSY & (1<<10) ) == (1<<10));
}

/* Read the conversion result */
uint16_t ADC_ConversionResultGet ( void ){
    return (uint16_t) ADC_REGS->ADC_RESULT;
}

/* Check whether result is ready */
bool ADC_ConversionStatusGet ( void ){
    bool status;
    status = ((( ADC_REGS->ADC_INTFLAG & (1<<0)) >> 0) != 0U);
    if ( status == true ){
        ADC_REGS->ADC_INTFLAG = (1<<0);
    }
    return status ;
}

void read_co2(uint32_t* co2){
    ADC_ConversionStart();
    while(!ADC_ConversionStatusGet); // Waiting for conversion
    uint16_t adc_value = ADC_ConversionResultGet(); // Store value
    //return sprintf("%d", adc_value);
    
    float ratio = (100.0f / adc_value) / (2.0 / 3.0);
    float transformed_value = 116.6020682f * powf(ratio, -2.769034857f);
    *co2 = (uint32_t)transformed_value;
    
    return;
}
