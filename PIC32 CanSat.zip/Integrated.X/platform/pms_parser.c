/**
 * @file pms_parser.c
 * @brief PMS7003 PM Sensor
 * 
 * Reads PM values from the PMSX003 series specifically 
 * standard atmospheric data
 * 
 * @author Christian Klein Ramos <christian.klein.ramos@eee.upd.edu.ph>
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 */

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

#include "../inc/pms_parser.h"

bool verify_pm(uint8_t* buffer){
    uint16_t checksum = 0;
    uint16_t counter_checksum;
    
    for (int i = 0; i < 32 - 2; i++) {
        checksum += buffer[i];
    }
    
    counter_checksum = (buffer[30] << 8) | buffer[31];
    
    return (checksum == counter_checksum);
}

bool read_pm(prog_state_t *ps) {
    if (platform_usart_pm_rx_busy()) {
        return false;  // Still receiving data
    }
    
    uint8_t *buffer = (uint8_t *)ps->pm_rx_desc_buf;
    
    // Check if valid start bytes
    if (buffer[0] == 0x42 && buffer[1] == 0x4D) {
        // Verify checksum
        if (!verify_pm(buffer)) {
            return false;
        }
        
        // Extract data - using the standard atmospheric data
        ps->pm1_0 = (buffer[10] << 8) | buffer[11]; 
        ps->pm2_5 = (buffer[12] << 8) | buffer[13]; 
        ps->pm10  = (buffer[14] << 8) | buffer[15];
        
        // Validate values
        if (ps->pm1_0 <= 1000 && ps->pm2_5 <= 1000 && ps->pm10 <= 1000) {
            return true;
        }
    }
    
    return false;
}