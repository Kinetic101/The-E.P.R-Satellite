/**
 * @file aht10.c
 * @brief AHT10 Temperature and Humidity Sensor
 *
 * Reads both temperature and humidity data 
 * 
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 */

#include <xc.h>
#include "../inc/aht10.h"
#include "../inc/tc.h"
#include "../inc/platform.h"

void AHT10_Initialize(){
    // Initialize AHT10
    int16_t buf[3] = {0xE1, 0x08, 0};
    SERCOM2_I2C_Write_Polled(0x38, buf, 3, 0);
}

void read_temp_humidity(double* humi, double* temp){
    // Initialize needed variables for transmission
    uint8_t addr = 0x38;                            
    uint8_t cond = 0;       // No repeated start                               
    int16_t buf[6] = {0xAC, 0x33, 0, 0, 0, 0};
    
    // Begin reading
    SERCOM2_I2C_Write_Polled(addr, buf, 3, cond);
    for(int i = 0; i < 1000000; i++){
        asm("nop");
    }
    SERCOM2_I2C_Read_Polled(addr, buf, 6, cond);
    
    // Read humidity
    int32_t humi_raw = ((buf[1] << 12) | (buf[2] << 4) | (buf[3] >> 4));
    *humi = humi_raw * 100.0 / 1048576.0;  // in %
    if(*humi >= 90){
        *humi -= 50.0;
    }

    // Read temperature
    int32_t temp_raw = (((buf[3] & 0x0F) << 16) | (buf[4] << 8) | buf[5]);
    *temp = ((temp_raw * 200.0) / 1048576.0) - 50.0;  // in C
    if(*temp >= 34){
        *temp -= 10.0;
    }
    
    return;
}