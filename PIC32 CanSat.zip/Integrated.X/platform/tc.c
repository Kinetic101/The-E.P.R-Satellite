/**
 * @file tc.c
 * @brief Timer Control (primarily for I2C)
 *
 * Configured for 4MHz clock
 * 
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 */

#include <xc.h>
#include "../inc/tc.h"
    
void TC_init(){
    /* Enabling the TC0 Bus Clock */
    GCLK_REGS -> GCLK_PCHCTRL[23] = (0x00000042);
    while ((GCLK_REGS -> GCLK_PCHCTRL[23] & (0x00000040)) == 0);
    
    /* Setting up the TC0 -> CTRLA Register */
    TC0_REGS->COUNT16.TC_CTRLA = (0x01); // Software reset at the start
    while ((TC0_REGS->COUNT16.TC_SYNCBUSY & (0x01)));
    
    TC0_REGS->COUNT16.TC_CTRLA |= ((0x0) << 2); // Set to 16-bit mode
    TC0_REGS->COUNT16.TC_CTRLA |= ((0x1) << 4); // Set the Prescaler and Counter Sync
    
    TC0_REGS->COUNT16.TC_CTRLA |= ((0x07) << 8); // Set the Prescaler Factor
    
    /* Setting up the WAVE Register */
    TC0_REGS->COUNT16.TC_WAVE = (0x01); // Match Frequency Operation mode
    
    /* Setting the Top Value */
    TC0_REGS->COUNT16.TC_CC[0] = (0x14); // Set CC0 (Top) value
    
    TC0_REGS->COUNT16.TC_CTRLA |= ((0x01) << 1); // Enable the TC0 Peripheral
    while ((TC0_REGS->COUNT16.TC_SYNCBUSY & ((0x01) << 1)));
}

void reset_tc(){
    TC0_REGS->COUNT16.TC_CTRLBSET = ((0x4) << 5);
    TC0_REGS->COUNT16.TC_COUNT = 0x1;
    return;
}

void change_timer(int sense){
    if(sense == 0){ // For BMP180 UT
        TC0_REGS->COUNT16.TC_CC[0] = 0x20; // Set CC0 (Top) value >= 4.5ms
    }
    else{ // For BMP180 UP or AHT10
        TC0_REGS->COUNT16.TC_CC[0] = 0x80; // Set CC0 (Top) value >= 75ms
    }
    reset_tc();
    return;
}

int read_tc() {
    // Allow read access of COUNT register 
    TC0_REGS->COUNT16.TC_CTRLBSET = ((0x4) << 5);
    return TC0_REGS->COUNT16.TC_COUNT;              // Return back the counter value
}