/**
 * @file bmp180.c
 * @brief BMP180 Temperature and Barometric Pressure Sensor
 * 
 * Reads both temperature and pressure data 
 *
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 */

#include <xc.h>
#include <math.h>

#include "../inc/bmp180.h"
#include "../inc/tc.h"
#include "../inc/platform.h"

void read_altitude(double* alt, uint32_t* pre){
    // Pre-read calibration values already, no sense to keep rereading every initialization
    int32_t ac1 = 8317;
    int32_t ac2 = -1206;
    int32_t ac3 = -14553;
    uint32_t ac4 = 34587;
    uint32_t ac5 = 24977;
    uint32_t ac6 = 20252;
    int32_t b1  = 6515;
    int32_t b2  = 49;
    int32_t mb  = -32768;
    int32_t mc  = -11786;
    int32_t md  = 2834;
    int32_t OSS = 0;            // Conserve the battery XD
    
    // Initialize needed variables for transmission
    uint8_t addr = 0x77;
    uint8_t cond = 1;           // Repeated start
    int16_t buf1[3] = {0xF4, 0x2E, 0xF6};

    // Begin reading UT
    SERCOM2_I2C_Write_Polled(addr, buf1, 3, cond);
    for(int i = 0; i < 10000; i++){
        asm("nop");
    }
    SERCOM2_I2C_Read_Polled(addr, buf1, 2, cond);

    // Read UT
    int32_t ut = (buf1[0] << 8) | buf1[1];
    
    // Just some BMP180 things
    int32_t x1 = ((ut - ac6) * ac5) >> 15;
    int32_t x2 = (mc << 11) / (x1 + md);
    int32_t b5 = x1 + x2;
    
    //*alt = (double) ((b5+8) >> 4) / 10; return; // Sanity check whether the temp's right in C
    
    // Begin reading UP
    int16_t buf2[3] = {0xF4, 0x34, 0xF6};
    SERCOM2_I2C_Write_Polled(addr, buf2, 3, cond);
    for(int i = 0; i < 10000; i++){
        asm("nop");
    }
    SERCOM2_I2C_Read_Polled(addr, buf2, 2, cond);
    
    // Read UP
    int32_t up = (buf2[0] << 8) | buf2[1];
    
    // Just some BMP180 things, again
    int32_t b6 = b5 - 4000;
    x1 = (b2 * ((b6 * b6) >> 12)) >> 11;
    x2 = (ac2 * b6) >> 11;
    int32_t x3 = x1 + x2;
    int32_t b3 = (((ac1 * 4 + x3) << OSS) + 2) >> 2;

    x1 = (ac3 * b6) >> 13;
    x2 = (b1 * ((b6 * b6) >> 12)) >> 16;
    x3 = ((x1 + x2) + 2) >> 2;
    uint32_t b4 = (ac4 * (uint32_t)(x3 + 32768)) >> 15;
    uint32_t b7 = ((uint32_t)up - b3) * (50000 >> OSS);

    int32_t p;
    if (b7 < 0x80000000){
        p = (b7 << 1) / b4;
    }
    else{
        p = (b7 / b4) << 1;
    }
    
    x1 = (p >> 8) * (p >> 8);
    x1 = (x1 * 3038) >> 16;
    x2 = (-7357 * p) >> 16;
    p = p + ((x1 + x2 + 3791) >> 4);
    
    // Real pressure in Pa
    *pre = p;

    // Calculate absolute altitude above sea level in meters
    *alt = 44330.0 * (1.0 - pow((double)(p / 101325.0), 0.1902949));
    
    return;
}