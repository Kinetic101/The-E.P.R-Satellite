/**
 * @file main.c
 * @brief The heart of the CanSat
 * 
 * This was modified from Sir de Villa's EEE 158 code 
 * 
 * @author Alberto de Villa <alberto.de.villa@eee.upd.edu.ph>
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 * @author Christian Klein Ramos <christian.klein.ramos@eee.upd.edu.ph>
 * @author Kent Joseph Palima <kent.joseph.palima@eee.upd.edu.ph>
 */

// Common include for the XC32 compiler
#include <xc.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>

// User defined
#include "inc/main.h"
#include "inc/platform.h"
#include "inc/adc.h"
#include "inc/tc.h"
#include "inc/bmp180.h"
#include "inc/aht10.h"
#include "inc/nmea_parser.h"
#include "inc/pms_parser.h"

/////////////////////////////////////////////////////////////////////////////

/*
 * Initialize the main program state
 * 
 * This style might be familiar to those accustomed to he programming
 * conventions employed by the Arduino platform.
 */
static void prog_setup(prog_state_t *ps){
	memset(ps, 0, sizeof(*ps));
    
	platform_init();
    
    ps->pm_rx_desc.buf = ps->pm_rx_desc_buf;
    ps->pm_rx_desc.max_len = 32;
    ps->pm_rx_desc.compl_type = PLATFORM_USART_RX_COMPL_NONE;
    platform_usart_pm_rx_async(&ps->pm_rx_desc);
	
    ps->gps_rx_desc.buf = ps->gps_rx_desc_buf;
    ps->gps_rx_desc.max_len = 128;
    ps->gps_rx_desc.compl_type = PLATFORM_USART_RX_COMPL_NONE;
    platform_usart_gps_rx_async(&ps->gps_rx_desc);
    
    platform_tick_count(&ps->i2c_time);
	return;
}

/////////////////////////////////////////////////////////////////////////////

/// Time elapsed function for I2C
static uint64_t time_elapsed(platform_timespec_t *start) {
    platform_timespec_t current, delta;
    platform_tick_count(&current);
    platform_tick_delta(&delta, &current, start);
    
    return (uint64_t)delta.nr_sec * 1000000 + delta.nr_nsec / 1000;
}

/////////////////////////////////////////////////////////////////////////////

/*
 * Do a single loop of the main program
 * 
 * This style might be familiar to those accustomed to he programming
 * conventions employed by the Arduino platform.
 */
static void prog_loop_one(prog_state_t *ps){
	// Do one iteration of the platform event loop first.
	platform_do_loop_one();
  
    // Read I2C sensors
    if(time_elapsed(&ps->i2c_time) >= 7500000){     // This is to give time for the USART sensors
        // Visual indicator whether transmission is happening - BLINK OFF
        PORT_SEC_REGS->GROUP[0].PORT_OUTSET = (1 << 15);
        
        // Read
        read_altitude(&ps->alt, &ps->pre);          // BMP180
        read_temp_humidity(&ps->hum, &ps->tem);		// AHT10
        
        // Log current time
        platform_tick_count(&ps->i2c_time);
        
        // Set flag
        ps->flags |= PROG_FLAG_I2C_UPDATE_PENDING;
    } 
    
    // Read MQ135
    do{
        read_co2(&ps->co2);
        
        // Set flag
        ps->flags |= PROG_FLAG_CO2_UPDATE_PENDING;
    } while(0);
   
    // Read GPS
    if(!platform_usart_gps_rx_busy()){
        char gps_data[] = "$GPGGA,1438.99343,N,12104.07767,E,023841.00,A,D*6D\r\n$GPGLL,1438.99343,N,12104.07767,E,023841.00,A,D*6D\r\n"; // For indoors testing
        char* buffer = ps->gps_rx_desc_buf;
        char* data;
        while ((data = strstr(buffer, "\r\n")) != NULL) {
            // Temporarily null-terminate for parsing functions
            char original_char_after_cr = *(data);
            *data = '\0'; 

            if (strncmp(buffer, "$GPGLL", 6) == 0) {
                if(!nmea_parse_gpgll_and_format(buffer, 
                                             ps->gpgll, 
                                             sizeof(ps->gpgll))) {
                    ps->gpgll[0] = '\0';  
                } 
            }
            *data = original_char_after_cr;
            buffer = data + 2;
        }
        // Set flag regardless whether there's useful information, parser already took care of it
        ps->flags |= PROG_FLAG_GPS_UPDATE_PENDING;
        
        // Restart reception
        memset(ps->gps_rx_desc_buf, 0, sizeof(ps->gps_rx_desc_buf));
        platform_usart_gps_rx_async(&ps->gps_rx_desc);
    }
    
    // Read PM
    if(!platform_usart_pm_rx_busy()){
        if(read_pm(ps)){    // Checksum must be verified, any delay would only add at most ~1sec
            ps->flags |= PROG_FLAG_PM_UPDATE_PENDING;
        }
        
        // Restart reception regardless of checksum status
        memset(ps->pm_rx_desc_buf, 0, sizeof(ps->pm_rx_desc_buf));
        platform_usart_pm_rx_async(&ps->pm_rx_desc);
    }
	////////////////////////////////////////////////////////////////////
   
    // Process any pending update flags
    do {
        // Do not transmit if at least one sensor has invalid data or is not working
		if ((ps->flags & PROG_FLAG_GPS_UPDATE_PENDING) == 0 || 
                (ps->flags & PROG_FLAG_PM_UPDATE_PENDING) == 0 ||
                (ps->flags & PROG_FLAG_I2C_UPDATE_PENDING) == 0 ||
                (ps->flags & PROG_FLAG_CO2_UPDATE_PENDING) == 0){
			break;
        }
		
		if (platform_usart_cdc_tx_busy()){
			break;
        }
		
		if ((ps->flags & PROG_FLAG_GEN_COMPLETE) == 0) {
			// Write to buffer
            memset(ps->tx_buf, 0, sizeof(ps->tx_buf));
            sprintf(ps->tx_buf, 
                    "%s,\n"
                    "Pressure: %d, Altitude: %.2f,\n"
                    "Temperature: %.2f, Humidity: %.2f,\n"
                    "PM1.0: %d, PM2.5: %d, PM10: %d,\n"
                    "CO2: %d,\n"
                    "\n", 
                    ps->gpgll, ps->pre, ps->alt, ps->tem, ps->hum, ps->pm1_0, ps->pm2_5, ps->pm10, ps->co2);
            
			// Dock that buffer
			ps->tx_desc[0].buf = ps->tx_buf;
			ps->tx_desc[0].len = strlen(ps->tx_buf);
		}
        
        // Send it to CDC and HC12
		if (platform_usart_cdc_tx_async(&ps->tx_desc[0], 1)) {
            // BLINK OFF
            PORT_SEC_REGS->GROUP[0].PORT_OUTCLR = (1 << 15);

            // Read again USARTs as to reduce errors
            memset(ps->pm_rx_desc_buf, 0, sizeof(ps->pm_rx_desc_buf));
            platform_usart_pm_rx_async(&ps->pm_rx_desc);
            memset(ps->gps_rx_desc_buf, 0, sizeof(ps->gps_rx_desc_buf));
            platform_usart_gps_rx_async(&ps->gps_rx_desc);

            // Clear flags
            ps ->flags &= ~(PROG_FLAG_GPS_UPDATE_PENDING | PROG_FLAG_PM_UPDATE_PENDING 
                    | PROG_FLAG_I2C_UPDATE_PENDING | PROG_FLAG_CO2_UPDATE_PENDING
                    | PROG_FLAG_GEN_COMPLETE);
		}
	} while(0);
	
	// Done
	return;
}

// main() -- the heart of the program
int main(void){
	prog_state_t ps;
	
	// Initialization time	
	prog_setup(&ps);
	
	/*
	 * Microcontroller main()'s are supposed to never return (welp, they
	 * have none to return to); hence the intentional infinite loop.
	 */
	for (;;) {
		prog_loop_one(&ps);
	}
    
    // This line must never be reached
    return 1;
}
