/*
 * @file script.js
 * @brief ESP32 Ground Station for Real Time Plotting of Sensor Data via Web Server (JS File)
 *
 * @author John Eric Estrada <john.eric.estrada@eee.upd.edu.ph>
 * Modified from https://randomnerdtutorials.com/esp32-plot-readings-charts-multiple/
 */

// Get current sensor readings when the page loads
window.addEventListener('load', getReadings);

// Create Temperature Chart
var chart1 = new Highcharts.Chart({
    chart:{
        renderTo:'chart-altitude'
    },

    series: [
        {
            name: 'Altitude',
            type: 'line',
            color: '#101D42',
            marker: {
                symbol: 'circle',
                radius: 3,
                fillColor: '#101D42',
            }
        },
    ],

    title: {
        text: undefined
    },

    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { second: '%H:%M:%S' }
    },

    yAxis: {
        title: {
            text: 'Meters'
        }
    },

    credits: {
        enabled: false
    }
});

// Create Temperature Chart
var chart2 = new Highcharts.Chart({
    chart:{
        renderTo:'chart-temperature'
    },

    series: [
        {
            name: 'Temperature',
            type: 'line',
            color: '#00A6A6',
            marker: {
                symbol: 'square',
                radius: 3,
                fillColor: '#00A6A6',
            }
        },
    ],

    title: {
        text: undefined
    },

    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { second: '%H:%M:%S' }
    },

    yAxis: {
        title: {
            text: 'Celsius'
        }
    },

    credits: {
        enabled: false
    }
});

// Create Humidity Chart
var chart3 = new Highcharts.Chart({
    chart:{
        renderTo:'chart-humidity'
    },

    series: [
        {
            name: 'Humidity',
            type: 'line',
            color: '#8B2635',
            marker: {
                symbol: 'triangle',
                radius: 3,
                fillColor: '#8B2635',
            }
        },
    ],

    title: {
        text: undefined
    },

    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { second: '%H:%M:%S' }
    },

    yAxis: {
        title: {
            text: 'Percent'
        }
    },

    credits: {
        enabled: false
    }
});

// Create CO2 Chart
var chart4 = new Highcharts.Chart({
    chart:{
        renderTo:'chart-co2'
    },

    series: [
        {
            name: 'CO2',
            type: 'line',
            color: '#71B48D',
            marker: {
                symbol: 'triangle-down',
                radius: 3,
                fillColor: '#71B48D',
            }
        },
    ],

    title: {
        text: undefined
    },

    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { second: '%H:%M:%S' }
    },

    yAxis: {
        title: {
            text: 'Parts Per Million'
        }
    },

    credits: {
        enabled: false
    }
});

// Create PM1.0 Chart
var chart5 = new Highcharts.Chart({
    chart:{
        renderTo:'chart-pm1'
    },

    series: [
        {
            name: 'PM1.0',
            type: 'line',
            color: '#101D42',
            marker: {
                symbol: 'circle',
                radius: 3,
                fillColor: '#101D42',
            }
        },
    ],

    title: {
        text: undefined
    },

    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { second: '%H:%M:%S' }
    },

    yAxis: {
        title: {
            text: 'ug/m3'
        }
    },

    credits: {
        enabled: false
    }
});

// Create PM2.5 Chart
var chart6 = new Highcharts.Chart({
    chart:{
        renderTo:'chart-pm2'
    },

    series: [
        {
            name: 'PM1.0',
            type: 'line',
            color: '#00A6A6',
            marker: {
                symbol: 'square',
                radius: 3,
                fillColor: '#00A6A6',
            }
        },
    ],

    title: {
        text: undefined
    },

    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { second: '%H:%M:%S' }
    },

    yAxis: {
        title: {
            text: 'ug/m3'
        }
    },

    credits: {
        enabled: false
    }
});

// Create PM10 Chart
var chart7 = new Highcharts.Chart({
    chart:{
        renderTo:'chart-pm10'
    },

    series: [
        {
            name: 'PM10',
            type: 'line',
            color: '#8B2635',
            marker: {
                symbol: 'triangle',
                radius: 3,
                fillColor: '#8B2635',
            }
        },
    ],

    title: {
        text: undefined
    },

    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { second: '%H:%M:%S' }
    },

    yAxis: {
        title: {
            text: 'ug/m3'
        }
    },

    credits: {
        enabled: false
    }
});

// Create Pressure Chart
var chart8 = new Highcharts.Chart({
    chart:{
        renderTo:'chart-pressure'
    },

    series: [
        {
            name: 'Pressure',
            type: 'line',
            color: '#101D42',
            marker: {
                symbol: 'circle',
                radius: 3,
                fillColor: '#101D42',
            }
        },
    ],

    title: {
        text: undefined
    },

    xAxis: {
        type: 'datetime',
        dateTimeLabelFormats: { second: '%H:%M:%S' }
    },

    yAxis: {
        title: {
            text: 'Pa'
        }
    },

    credits: {
        enabled: false
    }
});


//Plot temperature in the temperature chart
function plot(jsonValue) {
    var keys = Object.keys(jsonValue);
    console.log(keys);
    console.log(keys.length);

    for (var i = 0; i < keys.length; i++){
        var x = (new Date()).getTime();
        console.log(x);
        const key = keys[i];
        var y = Number(jsonValue[key]);
        console.log(y);

        if(i == 0){
            if(chart1.series[i].data.length > 40) {
                chart1.series[i].addPoint([x, y], true, true, true);
            } 
            else {
                chart1.series[i].addPoint([x, y], true, false, true);
            }
            document.getElementById("summary-altitude").innerText = y.toFixed(2);
        }
        else if(i == 1){
            if(chart2.series[0].data.length > 40) {
                chart2.series[0].addPoint([x, y], true, true, true);
            } 
            else {
                chart2.series[0].addPoint([x, y], true, false, true);
            }
            document.getElementById("summary-temperature").innerText = y.toFixed(2);
        }
        else if(i == 2){
            if(chart3.series[0].data.length > 40) {
                chart3.series[0].addPoint([x, y], true, true, true);
            } 
            else {
                chart3.series[0].addPoint([x, y], true, false, true);
            }
            document.getElementById("summary-humidity").innerText = y.toFixed(2);
        }
        else if(i == 3){
            if(chart4.series[0].data.length > 40) {
                chart4.series[0].addPoint([x, y], true, true, true);
            } 
            else {
                chart4.series[0].addPoint([x, y], true, false, true);
            }
            document.getElementById("summary-co2").innerText = y.toFixed(2);
        }
        else if(i == 4){
            if(chart5.series[0].data.length > 40) {
                chart5.series[0].addPoint([x, y], true, true, true);
            } 
            else {
                chart5.series[0].addPoint([x, y], true, false, true);
            }
            document.getElementById("summary-pm1").innerText = y.toFixed(2);
        }
        else if(i == 5){
            if(chart6.series[0].data.length > 40) {
                chart6.series[0].addPoint([x, y], true, true, true);
            } 
            else {
                chart6.series[0].addPoint([x, y], true, false, true);
            }
            document.getElementById("summary-pm2").innerText = y.toFixed(2);
        }
        else if(i == 6){
            if(chart7.series[0].data.length > 40) {
                chart7.series[0].addPoint([x, y], true, true, true);
            } 
            else {
                chart7.series[0].addPoint([x, y], true, false, true);
            }
            document.getElementById("summary-pm10").innerText = y.toFixed(2);
        }
        else if(i == 7){
            if(chart8.series[0].data.length > 40) {
                chart8.series[0].addPoint([x, y], true, true, true);
            } 
            else {
                chart8.series[0].addPoint([x, y], true, false, true);
            }
            document.getElementById("summary-pressure").innerText = y.toFixed(2);
        }

        // Update timestamp
        const now = new Date();
        const timeString = now.toLocaleTimeString();
        document.getElementById("summary-timestamp").innerText = timeString;

    }
}

// Function to get current readings on the webpage when it loads for the first time
function getReadings(){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var myObj = JSON.parse(this.responseText);
            console.log(myObj);
            plot(myObj);
        }
    };
    xhr.open("GET", "/readings", true);
    xhr.send();
}

if (!!window.EventSource) {
    var source = new EventSource('/events');

    source.addEventListener('open', function(e) {
        console.log("Events Connected");
    }, false);

    source.addEventListener('error', function(e) {
        if (e.target.readyState != EventSource.OPEN) {
            console.log("Events Disconnected");
        }
    }, false);

    source.addEventListener('message', function(e) {
        console.log("message", e.data);
    }, false);

    source.addEventListener('new_readings', function(e) {
        console.log("new_readings", e.data);
        var myObj = JSON.parse(e.data);
        console.log(myObj);
        plot(myObj);

        if (myObj.latitude && myObj.longitude) {
            updateMap(parseFloat(myObj.latitude), parseFloat(myObj.longitude));
        }
    }, false);
}

// Initialize Leaflet map
let map = L.map('map').setView([14.649838960196734, 121.06831134477346], 13); // Default Manila
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);
let marker = L.marker([14.649838960196734, 121.06831134477346]).addTo(map);

// Function to update map location
function updateMap(lat, lng) {
    marker.setLatLng([lat, lng]);
    map.setView([lat, lng], map.getZoom());
    document.getElementById("location-lat").innerText = lat.toFixed(10);
    document.getElementById("location-long").innerText = lng.toFixed(10);
}

// Handle tab switching
function openTab(evt, tabName) {
    const tabcontent = document.getElementsByClassName("tabcontent");
    for (let i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    const tablinks = document.getElementsByClassName("tablinks");
    for (let i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

setTimeout(() => {
    map.invalidateSize();
}, 100);

document.getElementById("defaultOpen").click();
